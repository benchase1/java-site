public class Main
{
 	public static void main(String[] args)
  {
    // version info
    System.out.println("Battleship 1.0.3");
    // starts the game!
 		GameFrame game = new GameFrame();
 		game.sendNum();
 	}
 }
