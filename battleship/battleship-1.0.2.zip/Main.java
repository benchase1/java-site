public class Main
{
 	public static void main(String[] args)
  {
    // starts the game!
 		BattleshipGameFrame game = new BattleshipGameFrame();
 		game.sendNum();
 	}
 }
