import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

 public class ScorePanelShipButton extends JButton
 {
 	public int spaceCount;
 	public ScorePanelShipButton(int spaceCountTemp)
  {
 		spaceCount = spaceCountTemp;
 	}

 }
