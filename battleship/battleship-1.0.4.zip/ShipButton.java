import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

 public class ShipButton extends JButton
 {
 	public int spaceCount;
 	public ShipButton(int spaceCountTemp)
  {
 		spaceCount = spaceCountTemp;
 	}

 }
